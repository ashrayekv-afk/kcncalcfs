# Version 9.1.0 software verification — 27 October 2026

This release integrates the approved corneal preview into the bilateral calculator. Each imported eye and visit drives the viewer. Both eyes share rotation, zoom and physical scale, with natural appearance, five map tints, whole/section views and five simultaneous point measurements. The synthetic-eye option and observed-change/evidence drawer remain removed.

These checks establish software behavior. They do not validate an exact 1:1 patient eye, clinical measurement accuracy or patient optics.

## Retained calculator behavior

- All **41 Python unittest checks** and **five retained audit scripts** passed.
- **Twenty-one Python/model files** are identical to 9.0.9 apart from the prescribed interface-version identifiers. Frozen coefficients, feature definitions, assessment logic and PDF generation were not changed or retrained.
- **Thirty-six complete eye results** match 9.0.9 exactly after excluding `ui_version`: baseline and longitudinal modes, both eyes, ages 14/24/60 and intervals 90/180/730 days. The comparison checks complete results, not just rounded scores.
- **Twelve JavaScript suite files** passed, covering import merge, bilateral import/review, extraction integrity, full report/display handling, integrated model/reader behavior, map identification, progression summaries, score bands and the independent OCR reader.
- The three retained geometry suites also passed unchanged: **70 regional/image/3D/cone groups**, **24 shape-inspection/renderer groups** and **30 patient-eye accuracy checks**.

Python declarations retain `streamlit==1.50.0`, `reportlab==4.4.9` and `numpy>=1.26.4,<3`. This release does not claim that every dependency is the newest published version.

## Integrated model and reader

The new adapter has **12 focused checks**. They cover preservation of native geometry and independent pachymetry, source immutability, accepted calibration endpoints, conservative partial reconstruction, absence of invented cone height, supported anterior data without thickness, sparse posterior point fields, aperture matching and explicit source status.

The new reader has **seven focused checks**, including two errors found during actual-source verification: a punctuation variant in a full posterior header and an OCR numeral conflicting with a readable glyph anchor. Posterior reference-sphere radii now require agreement between the primary full header and a secondary numeric crop. Conflicting legend anchors remain unavailable. The fixes contain no patient-specific replacement values.

The retained six full-report reader checks and seven full-report eye checks also pass. Central regional-comparison arrays remain unchanged. New display fields do not stretch one physical aperture over another.

### Actual supplied reports

Four original image pages from the supplied bilateral examination were processed by the production reader and the bundled browser Tesseract 7 workers. This pass made **62 genuine OCR calls**, with **zero external requests, page errors or failed requests**. It used no manual transcriptions or substituted OCR responses.

The reader recovered anterior curvature, posterior curvature and thickness for both eyes, plus both anterior and posterior elevation fields. Readable sphere radii agree with the printed headers. An unreadable red posterior fitting-diameter label remains unavailable. Accepted elevation calibration excludes conflicting upper legend text and retains conservative bounds.

The resulting right-eye display uses the supported 9-mm aperture. The left-eye display uses supported patches within the central 6-mm aperture and is explicitly labeled a partial reconstruction. Clipped or unsupported cells remain absent. Both eyes retain all five measurement fields where locally supported.

Checks on these actual-source models confirm unchanged input objects, the specified BFS-plus-elevation coordinate equation, and front-to-inner distances equal to retained thickness within floating-point tolerance. This verifies the reconstruction arithmetic, not the accuracy of the source images or the assumed reference-sphere pose.

## Browser viewer acceptance

The integrated viewer passed **28 browser groups**: 14 with actual WebGL and the same 14 with WebGL unavailable, exercising the Canvas fallback. These checks use synthetic fixtures and reviewed supplied-report inputs.

Coverage includes:

- Native coordinate preservation and device pachymetry independent of vertical surface separation.
- All five tint modes and section controls without changing source geometry or point values.
- Shared drag/zoom and identical pixels per millimetre for OD and OS.
- X/Y point selection, missing values and all five simultaneous readouts.
- Baseline/latest switching without borrowing data between eyes or visits.
- Empty, one-eye, missing-visit and map-only states. Map-only inputs retain available point values while patient geometry stays unavailable.
- Explicit report-image approximation, partial reconstruction and source quality labels.
- Combined PNG export with both eyes, selected values, scales and source limitations.
- Layouts at 736, 390 and 320 pixels without horizontal overflow.
- Repeated binding/clearing and disposal of event handlers, observers and graphics resources.

The new corneal renderer uses true physical scale without height amplification. Native thickness is a device value at the selected front point; it is not represented by a line joining corresponding native grid coordinates. Image-derived inner boundaries retain their normal-offset thickness construction. Natural/tinted appearance uses lighting for depth, with numerical interpretation provided by the point values.

Focused component checks using the approved reviewed inputs matched all five initial point readouts. Both eye panels used identical physical scale. Desktop, phone, tint and fallback images were visually inspected. QA screenshots and patient data are excluded from the release.

## Bundled OCR runtime

The official `tesseract.js` and `tesseract.js-core` **7.0.0** browser assets are bundled with licenses and an asset manifest. Package tarballs were verified against published SHA-512 integrity and SHA-1 checksums; individual shipped assets have SHA-256 hashes.

The primary worker selects the supported local plain, SIMD or relaxed-SIMD LSTM core. The independent secondary worker retains its plain LSTM core. Existing English trained models are unchanged. Image-report OCR no longer needs a separate runtime CDN download; PDF support retains its existing loader requirements.

A browser smoke test exercised both local workers on generated text and an original report header: all eight resource requests were local, with no failed or external requests. The complete four-page actual-source pass described above also used only local resources. Browser security checks were not disabled.

## Actual application acceptance

The clean packaged Streamlit application passed **eight browser integration groups**. Its production OCR constructors ran inside the shipped iframe and content-security policy, read the original report header, and made no external or failed requests. No uncaught page errors were recorded.

The automatically extracted original-source objects were bound through the application import protocol to both eye surfaces. All five tints preserved source geometry and selected values. Linked controls and the combined PNG worked. Editing OD invalidated only the associated eye, and next-patient reset cleared both scores and corneal data.

These are complementary checks: actual OCR processes the original report pixels, and the application binding test submits the resulting parsed objects. They do not constitute a complete automated traversal of every ZIP-upload and scalar-review interaction.

Visual review of the packaged application found inherited calculator styles affecting selected controls, word wrapping and canvas touch handling. The final viewer stylesheet scopes those rules to preserve the integrated controls within the existing app.

## Packaging and clean installation

All **11 launcher integrity checks** passed, covering missing/corrupt bundles, checksum mismatch, unsafe paths/symlinks, missing files, cache reuse, version switching, concurrent installation, arbitrary working directory and propagation of original runtime exceptions.

A clean package passed exact membership, ZIP CRC, every source hash and size, matching launcher/runtime checksum, all **39 local HTML asset references**, and actual extracted-launcher startup from a different working directory. Baseline and longitudinal OD/OS assessment events produced scores and valid PDF headers. Its complete 36-result calculator comparison also passed. The final archive is checked again after release documentation and style changes.

The upload contains exactly five files: four repository-root files and `.streamlit/config.toml`. The inner runtime contains **124 files**, including a generated manifest for **123 source entries**. All 105 prior source entries remain; additions are the integrated model/renderer/style, two focused test files and 13 upstream OCR runtime assets. Every individual upload file is below 25 MiB.

An explicit source allowlist excludes patient reports, extracted patient grids, reference photographs, QA screenshots, credentials and development environments. The launcher verifies the matching runtime before extracting it.

## Verification limits

The actual-source OCR test covers the supplied four pages; it does not establish reliable reading of every report layout or image quality. OCR agreement does not guarantee a correct value, so the existing import review remains necessary.

No native patient surface ground truth was supplied. Passing tests does not establish clinical accuracy, repeatability, scan registration, progression performance, surgical-planning suitability or a simulation of patient vision. Image geometry retains color quantization, missing-data and reference-pose limits. The sclera, iris and unmeasured periphery remain reference anatomy. See `docs/SURFACE_DATA.md` for the coordinate and missing-data contract.

This is a locally verified upload package. It has not been deployed to the user's GitHub repository or Streamlit account.
