/* NKPI anatomical eye renderer.
 * A reference globe and procedural iris surround the supplied corneal surface.
 * Patient heights are never inferred from curvature or altered by this renderer.
 * No external textures, libraries, network access, or optical ray-tracing claims.
 */
(function(root){'use strict';
const finite=Number.isFinite,clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const unit=v=>{const n=Math.hypot(...v)||1;return v.map(x=>x/n);};
const sub=(a,b)=>a.map((x,i)=>x-b[i]);
const cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
const dot=(a,b)=>a.reduce((s,x,i)=>s+x*b[i],0);
const palettes={thickness:[[139,105,208],[133,182,217],[188,228,222]],other:[[73,132,197],[80,181,188],[221,211,123],[213,126,100]]};
function color(model,id,value){
 if(id==='form')return [151,202,216];if(id==='shape')return [116,186,207];
 if(!finite(value))return [70,80,95];
 const l=model.overlays?.find(v=>v.id===id);if(!l)return [70,80,95];
 const n=id==='posterior'?Math.abs(value):value,t=clamp((n-l.min)/Math.max(1e-8,l.max-l.min),0,1),p=id==='thickness'?palettes.thickness:palettes.other;
 const x=t*(p.length-1),i=Math.min(p.length-2,Math.floor(x)),f=x-i;
 return p[i].map((v,k)=>v*(1-f)+p[i+1][k]*f);
}
const vertexSource=`
attribute vec3 aPosition;
attribute vec3 aNormal;
attribute float aValue;
uniform mat3 uRotation;
uniform vec2 uViewport;
uniform float uCenterZ;
uniform float uScale;
uniform float uPerspective;
uniform float uDepthBias;
uniform float uPointSize;
varying vec3 vNormal;
varying vec3 vLocal;
varying float vValue;
void main(){
 vec3 p=uRotation*(aPosition-vec3(0.,0.,uCenterZ));
 float w=uPerspective>0.?(uPerspective-p.z)/uPerspective:1.;
 gl_Position=vec4(p.x*uScale*2./uViewport.x,p.y*uScale*2./uViewport.y+.04*w,-p.z/64.+uDepthBias*w,w);
 gl_PointSize=uPointSize;
 vNormal=uRotation*aNormal;vLocal=aPosition;vValue=aValue;
}`;
const fragmentSource=`
precision highp float;
uniform int uMode;
uniform vec2 uRange;
uniform int uThickness;
uniform float uLimbus;
uniform vec4 uColor;
varying vec3 vNormal;
varying vec3 vLocal;
varying float vValue;
vec3 mapColor(float value){
 float t=clamp((value-uRange.x)/max(.00000001,uRange.y-uRange.x),0.,1.);
 if(uThickness==1){
  vec3 a=vec3(139.,105.,208.)/255.,b=vec3(133.,182.,217.)/255.,c=vec3(188.,228.,222.)/255.;
  return t<.5?mix(a,b,t*2.):mix(b,c,(t-.5)*2.);
 }
 vec3 a=vec3(73.,132.,197.)/255.,b=vec3(80.,181.,188.)/255.,c=vec3(221.,211.,123.)/255.,d=vec3(213.,126.,100.)/255.;
 return t<1./3.?mix(a,b,t*3.):t<2./3.?mix(b,c,(t-1./3.)*3.):mix(c,d,(t-2./3.)*3.);
}
void main(){
 if(uMode==5){gl_FragColor=vec4(mapColor(vValue),1.);return;}
 if(uMode==8){gl_FragColor=uColor;return;}
 if(uMode==10){
  float r=length(gl_PointCoord-.5)*2.;if(r>.97||r<.51)discard;
  gl_FragColor=r>.80?vec4(.03,.08,.12,1.):vec4(1.,.94,.73,1.);return;
 }
 vec3 n=normalize(vNormal);if(!gl_FrontFacing)n=-n;
 vec3 key=normalize(vec3(-.65,.85,1.4)),fill=normalize(vec3(.9,.15,.5)),halfV=normalize(key+vec3(0.,0.,1.));
 float diffuse=max(0.,dot(n,key)),secondary=max(0.,dot(n,fill));
 float facing=abs(n.z),rim=pow(1.-facing,3.),spec=pow(max(0.,dot(n,halfV)),80.);
 if(uMode==0){
  float grain=sin(vLocal.x*41.+sin(vLocal.y*23.))*sin(vLocal.y*47.+vLocal.z*13.);
  vec3 base=vec3(.91,.935,.96)+grain*.0014;
  vec3 rgb=base*(.47+.45*diffuse+.10*secondary)+vec3(.10,.13,.17)*rim+vec3(.20)*spec;
  gl_FragColor=vec4(clamp(rgb,0.,1.),1.);return;
 }
 if(uMode==1){
  float r=length(vLocal.xy),a=atan(vLocal.y,vLocal.x),pr=1.74+.014*sin(a*83.)+.009*sin(a*119.);
  if(r<pr){gl_FragColor=vec4(.008,.014,.023,1.);return;}
  float t=clamp((r-pr)/(uLimbus-pr-.10),0.,1.);
  float warp=2.1*sin(r*1.8+a*7.)+.4*sin(r*4.7+a*19.)+.6*sin(a*29.);
  float fiber=.50+.22*sin(a*113.+warp)+.10*sin(a*197.-warp*1.4)+.05*sin(a*281.+r*3.2);
  float folds=.5+.5*sin(a*53.+sin(a*17.)*.6+r*.38);
  float band=.80+.20*sin(t*10.+sin(a*29.)*.20);
  float glint=pow(clamp(fiber,0.,1.),2.3);
  vec3 low=vec3(.055,.130,.185),high=vec3(.185,.345,.430);
  vec3 iris=mix(low,high,clamp(fiber*.79+folds*.14,0.,1.))*band;
  iris+=vec3(.020,.035,.038)*glint;
  iris=mix(iris,vec3(.08,.135,.15),.28*exp(-pow((t-.27)/.065,2.)));
  iris*=1.-.76*smoothstep(.87,1.,t);
  iris*=.56+.44*smoothstep(0.,.05,t);
  gl_FragColor=vec4(iris*(.78+.23*diffuse),1.);return;
 }
 if(uMode==3||uMode==9){
  float fresnel=pow(1.-facing,1.4);
  float broad=pow(max(0.,dot(n,halfV)),55.);
  float pin=pow(max(0.,dot(n,normalize(vec3(-.38,.49,1.65)))),280.);
  vec3 reflection=mix(vec3(.67,.88,1.),vec3(.96,.985,1.),clamp(broad*.65+pin,0.,1.));
  float alpha=.02+.92*fresnel+.14*broad+.13*pin;
  if(uMode==9)alpha=.008+.10*fresnel;
  gl_FragColor=vec4(reflection,clamp(alpha,0.,.80));return;
 }
 if(uMode==6){
  vec3 base=vValue>.5?vec3(.322,.722,.682):vValue>-.5?vec3(.773,.6,.353):vec3(.38,.45,.55);
  gl_FragColor=vec4(base,1.);return;
 }
 if(uMode==7){
  gl_FragColor=vec4(vec3(.89,.74,.48)*(.64+.36*diffuse),1.);return;
 }
 vec3 base=vec3(.38,.66,.77),rgb=base*(.26+.60*diffuse+.14*secondary)+vec3(.30)*spec+vec3(.10,.15,.19)*rim;
 gl_FragColor=vec4(clamp(rgb,0.,1.),1.);
}`;
const backgroundVertex=`attribute vec2 aPosition;varying vec2 vUV;void main(){vUV=aPosition*.5+.5;gl_Position=vec4(aPosition,1.,1.);}`;
const backgroundFragment=`precision mediump float;varying vec2 vUV;uniform vec2 uSize;void main(){
 vec2 q=(vUV-vec2(.43,.60))*vec2(uSize.x/uSize.y,1.);
 float glow=exp(-dot(q,q)*4.0);
 vec3 bg=mix(vec3(.022,.031,.056),vec3(.060,.091,.146),glow*.78);
 float shadow=exp(-pow((vUV.x-.52)*3.5,2.)-pow((vUV.y-.16)*15.,2.));
 gl_FragColor=vec4(bg*(1.-shadow*.40),1.);
}`;
function createProgram(gl,vs,fs){
 const shaders=[];try{
  for(const [kind,text]of [[gl.VERTEX_SHADER,vs],[gl.FRAGMENT_SHADER,fs]]){const s=gl.createShader(kind);shaders.push(s);gl.shaderSource(s,text);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(s)||'Eye shader compilation failed.');}
  const p=gl.createProgram();for(const s of shaders)gl.attachShader(p,s);gl.linkProgram(p);if(!gl.getProgramParameter(p,gl.LINK_STATUS)){const message=gl.getProgramInfoLog(p);gl.deleteProgram(p);throw Error(message||'Eye shader linking failed.');}return p;
 }finally{for(const s of shaders)gl.deleteShader(s);}
}
function makeSclera(m){
 const p=[],n=[],ids=[],N=128,J=72,R=12,start=Math.asin(m.radius/R);
 for(let j=0;j<=J;j++)for(let i=0;i<N;i++){
  const t=start+(Math.PI-start-.000001)*j/J,a=i*2*Math.PI/N,v=[Math.sin(t)*Math.cos(a),Math.sin(t)*Math.sin(a),Math.cos(t)];
  p.push([v[0]*R,v[1]*R,m.globeCenter+v[2]*R]);n.push(v);
 }
 for(let j=0;j<J;j++)for(let i=0;i<N;i++){const a=j*N+i,b=j*N+(i+1)%N,c=a+N,d=b+N;ids.push([a,c,b],[b,c,d]);}
 return {positions:p,normals:n,triangles:ids};
}
function makeIris(m){
 const N=256,r=m.radius-.10,z=m.limbusZ-.48,p=[[0,0,z]],n=[[0,0,1]],ids=[];
 for(let i=0;i<N;i++){const a=i*2*Math.PI/N;p.push([r*Math.cos(a),r*Math.sin(a),z]);n.push([0,0,1]);}
 for(let i=0;i<N;i++)ids.push([0,1+i,1+(i+1)%N]);
 return {positions:p,normals:n,triangles:ids,radius:r,z};
}
class AnatomicalEye{
 constructor(canvas,{shapeAPI}={}){
  this.canvas=canvas;this.shapeAPI=shapeAPI||root.NKPIPatientShape;this.available=false;this.error='';this.buffers=new Set();this.programs=[];this.meshCache=new WeakMap();this.last=null;this.disposed=false;
  if(!this.shapeAPI){this.error='The corneal surface module is unavailable.';return;}
  try{
   this.gl=canvas.getContext('webgl',{alpha:false,antialias:true,depth:true,stencil:false,premultipliedAlpha:false,preserveDrawingBuffer:true,powerPreference:'low-power'});
   if(!this.gl){this.error='WebGL is unavailable.';return;}
   const gl=this.gl;this.program=createProgram(gl,vertexSource,fragmentSource);this.programs.push(this.program);this.background=createProgram(gl,backgroundVertex,backgroundFragment);this.programs.push(this.background);
   this.attrs={};for(const k of ['aPosition','aNormal','aValue'])this.attrs[k]=gl.getAttribLocation(this.program,k);
   this.uniforms={};for(const k of ['uRotation','uViewport','uCenterZ','uScale','uPerspective','uDepthBias','uPointSize','uMode','uRange','uThickness','uLimbus','uColor'])this.uniforms[k]=gl.getUniformLocation(this.program,k);
   this.bgPosition=gl.getAttribLocation(this.background,'aPosition');this.bgSize=gl.getUniformLocation(this.background,'uSize');
   this.quad=this.buffer(new Float32Array([-1,-1,1,-1,-1,1,1,1]));
   this.available=true;
   this.onLost=e=>{e.preventDefault();this.available=false;this.error='WebGL context was lost.';};canvas.addEventListener?.('webglcontextlost',this.onLost,false);
  }catch(e){this.error=e.message||'WebGL initialization failed.';this.available=false;}
 }
 buffer(data,target){const gl=this.gl,b=gl.createBuffer();this.buffers.add(b);gl.bindBuffer(target||gl.ARRAY_BUFFER,b);gl.bufferData(target||gl.ARRAY_BUFFER,data,gl.STATIC_DRAW);return b;}
 geometry(positions,normals,triangles){
  const values=new Float32Array(positions.length*6);
  positions.forEach((p,i)=>{values.set(p,i*6);values.set(normals[i]||[0,0,1],i*6+3);});
  const indices=[];for(const ids of triangles){if(ids.some(i=>!positions[i]||!positions[i].every(finite)))continue;const [a,b,c]=ids,n=cross(sub(positions[b],positions[a]),sub(positions[c],positions[a]));indices.push(dot(n,normals[a])<0?[a,c,b]:[a,b,c]);}
  const flat=new Uint16Array(indices.flat()),g={buffer:this.buffer(values),positions,normals,triangles:indices,all:{buffer:this.buffer(flat,this.gl.ELEMENT_ARRAY_BUFFER),count:flat.length},fields:new Map(),subsets:new Map()};
  return g;
 }
 subset(g,key,predicate){
  if(g.subsets.has(key))return g.subsets.get(key);
  const indices=new Uint16Array(g.triangles.filter(predicate).flat()),out={buffer:this.buffer(indices,this.gl.ELEMENT_ARRAY_BUFFER),count:indices.length};g.subsets.set(key,out);return out;
 }
 field(g,key,values){
  if(!g.fields.has(key))g.fields.set(key,this.buffer(new Float32Array(values)));return g.fields.get(key);
 }
 build(source){
  if(this.meshCache.has(source))return this.meshCache.get(source);
  const api=this.shapeAPI,m=api.anatomicalMesh(source),v=m.vertices;
  const front=this.geometry(v.map(v=>v.front),v.map(v=>v.frontNormal),m.triangles);
  const validBack=m.triangles.filter(ids=>ids.every(i=>v[i].back?.every(finite)));
  const back=validBack.length?this.geometry(v.map(v=>v.back||v.front),v.map(v=>v.backNormal||[0,0,-1]),validBack):null;
  const sclera=makeSclera(m),iris=makeIris(m),scene={m,source,front,back,sclera:this.geometry(sclera.positions,sclera.normals,sclera.triangles),iris:this.geometry(iris.positions,iris.normals,iris.triangles),irisZ:iris.z,irisRadius:iris.radius,wall:null,contours:null};
  const c=v.map(v=>v.provenance==='source'?1:v.provenance==='filled'?0:-1);this.field(front,'coverage',c);if(back)this.field(back,'coverage',c);
  this.meshCache.set(source,scene);return scene;
 }
 bind(g,field){
  const gl=this.gl,a=this.attrs;gl.bindBuffer(gl.ARRAY_BUFFER,g.buffer);gl.enableVertexAttribArray(a.aPosition);gl.vertexAttribPointer(a.aPosition,3,gl.FLOAT,false,24,0);gl.enableVertexAttribArray(a.aNormal);gl.vertexAttribPointer(a.aNormal,3,gl.FLOAT,false,24,12);
  if(field){gl.bindBuffer(gl.ARRAY_BUFFER,field);gl.enableVertexAttribArray(a.aValue);gl.vertexAttribPointer(a.aValue,1,gl.FLOAT,false,0,0);}else{gl.disableVertexAttribArray(a.aValue);gl.vertexAttrib1f(a.aValue,0);}
 }
 draw(g,mode,subset,field){if(!g)return;const gl=this.gl,index=subset||g.all;if(!index.count)return;this.bind(g,field);gl.uniform1i(this.uniforms.uMode,mode);gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,index.buffer);gl.drawElements(gl.TRIANGLES,index.count,gl.UNSIGNED_SHORT,0);}
 configure(frame){
  const gl=this.gl,u=this.uniforms;gl.useProgram(this.program);gl.uniformMatrix3fv(u.uRotation,false,new Float32Array(frame.rotation.flat()));gl.uniform2f(u.uViewport,frame.width,frame.height);gl.uniform1f(u.uCenterZ,frame.centerZ);gl.uniform1f(u.uScale,frame.scale);gl.uniform1f(u.uPerspective,frame.perspective);gl.uniform1f(u.uDepthBias,0);gl.uniform1f(u.uPointSize,14);gl.uniform1f(u.uLimbus,frame.scene.m.radius);gl.uniform4f(u.uColor,1,1,1,1);
 }
 render(model,options={}){
  if(!this.available||this.disposed||this.gl.isContextLost())return null;
  const state={yaw:-.15,pitch:-.82,roll:0,zoom:1,eyeContext:true,cut:false,color:'shape',coverage:false,emphasis:1,selected:null,eye:'OS',visit:'latest',...options};
  state.emphasis=model.kind==='estimated'&&finite(state.emphasis)?clamp(state.emphasis,1,6):1;
  const source=this.shapeAPI.emphasizeElevation(model,state.emphasis),scene=this.build(source),m=scene.m,gl=this.gl,w=this.canvas.width,h=this.canvas.height;
  const rotation=[[1,0,0],[0,1,0],[0,0,1]].map(v=>this.shapeAPI.rotate(v,state.yaw,state.pitch,state.roll||0));
  const centerZ=state.eyeContext?m.globeCenter:(m.focusZ??m.apex-.6);
  const scale=Math.min(w*.40,h*.35)/(state.eyeContext?12:m.radius)*(state.zoom||1);
  // A mild perspective view changes the camera only. Corneal close-up/profile
  // remain orthographic, and every physical x/y/z coordinate is unchanged.
  const perspective=state.eyeContext&&state.perspective!==false?(finite(state.cameraDistance)?clamp(state.cameraDistance,35,100):45):0;
  const frame={scene,model,source,state,rotation,centerZ,scale,perspective,width:w,height:h};this.last=frame;
  gl.viewport(0,0,w,h);gl.disable(gl.BLEND);gl.disable(gl.CULL_FACE);gl.disable(gl.DEPTH_TEST);gl.depthMask(true);gl.clearDepth(1);gl.clear(gl.DEPTH_BUFFER_BIT);
  gl.useProgram(this.background);gl.bindBuffer(gl.ARRAY_BUFFER,this.quad);gl.enableVertexAttribArray(this.bgPosition);gl.vertexAttribPointer(this.bgPosition,2,gl.FLOAT,false,0,0);gl.uniform2f(this.bgSize,w,h);gl.drawArrays(gl.TRIANGLE_STRIP,0,4);
  this.configure(frame);gl.enable(gl.DEPTH_TEST);gl.depthFunc(gl.LEQUAL);gl.enable(gl.CULL_FACE);gl.cullFace(gl.BACK);gl.frontFace(gl.CCW);
  this.draw(scene.sclera,0);this.draw(scene.iris,1);
  const cut=state.cut,cutPredicate=ids=>!cut||ids.every(i=>m.vertices[i].front[0]<=1e-8),subset=cut?this.subset(scene.front,'cut',cutPredicate):scene.front.all;
  const backSubset=scene.back?(cut?this.subset(scene.back,'cut',cutPredicate):scene.back.all):null;
  const layer=state.color==='combined'?'anterior':state.color,requestedMap=!['shape','form'].includes(state.color),isMap=requestedMap&&m.overlays.some(l=>l.id===state.color)&&m.overlays.some(l=>l.id===layer);
  if(state.coverage){
   const coverageValues=requestedMap?m.vertices.map(v=>!isMap?-1:finite(v[layer])?1:v.displayInterpolated?.[layer]?0:-1):null;
   const coverageField=requestedMap?this.field(scene.front,'coverage:'+state.color,coverageValues):scene.front.fields.get('coverage');
   this.draw(scene.front,6,subset,coverageField);
   if(cut&&scene.back){gl.disable(gl.CULL_FACE);this.draw(scene.back,6,backSubset,requestedMap?this.field(scene.back,'coverage:'+state.color,coverageValues):scene.back.fields.get('coverage'));gl.enable(gl.CULL_FACE);}
  }else if(state.color==='form'){
   this.draw(scene.front,4,subset);
   if(cut&&scene.back){gl.disable(gl.CULL_FACE);this.draw(scene.back,4,backSubset);gl.enable(gl.CULL_FACE);}
  }else{
   let clearSubset=subset;
   if(requestedMap){
    const mapValue=v=>source.mapSource==='image'?v.displayValues?.[layer]:v[layer];
    const measured=ids=>isMap&&ids.every(i=>finite(mapValue(m.vertices[i])));
    const inSource=ids=>ids.every(i=>Math.hypot(m.vertices[i].front[0],m.vertices[i].front[1])<=source.radius+1e-8);
    const unavailable=this.subset(scene.front,'unavailable:'+state.color+(cut?':cut':''),ids=>cutPredicate(ids)&&inSource(ids)&&!measured(ids));
    gl.uniform4f(this.uniforms.uColor,.251,.294,.353,1.);this.draw(scene.front,8,unavailable);
    gl.uniform4f(this.uniforms.uColor,1,1,1,1);
    const mapSubset=this.subset(scene.front,'map:'+state.color+(cut?':cut':''),ids=>cutPredicate(ids)&&measured(ids));
    clearSubset=this.subset(scene.front,'clear:'+state.color+(cut?':cut':''),ids=>cutPredicate(ids)&&!measured(ids)&&!inSource(ids));
    const values=m.vertices.map(v=>finite(mapValue(v))?(layer==='posterior'?Math.abs(mapValue(v)):mapValue(v)):0),field=this.field(scene.front,layer,values),l=model.overlays.find(v=>v.id===layer)||m.overlays.find(v=>v.id===layer);
    if(l&&isMap){gl.uniform2f(this.uniforms.uRange,l.min,l.max);gl.uniform1i(this.uniforms.uThickness,layer==='thickness'?1:0);
    this.draw(scene.front,5,mapSubset,field);}
   }
   gl.enable(gl.BLEND);gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA);gl.depthMask(false);
   if(scene.back){gl.disable(gl.CULL_FACE);this.draw(scene.back,9,backSubset);gl.enable(gl.CULL_FACE);}
   this.draw(scene.front,3,clearSubset);
   gl.depthMask(true);gl.disable(gl.BLEND);
   if(state.color==='combined'&&isMap)this.drawContours(frame);
  }
  if(cut&&scene.back)this.drawWall(frame);
  if(Number.isInteger(state.selected)&&source.vertices[state.selected])this.drawSelection(frame,state.selected);
  gl.flush();
  return {pickAt:(x,y)=>this.pickAt(x,y),projectPoint:p=>this.projectPoint(p),width:w,height:h,state,renderer:'webgl',sourceVertices:source.vertices.length};
 }
 drawWall(frame){
  const {scene}=frame,gl=this.gl;
  if(!scene.wall){
   const faces=this.shapeAPI.meshFaces(scene.m,true,true).filter(f=>f.side==='wall'&&f.positions.every(p=>p?.every(finite))),p=[],n=[],tri=[];
   for(const f of faces){const first=p.length;p.push(...f.positions);n.push(...f.positions.map(()=>f.normal));tri.push([first,first+1,first+2]);}
   scene.wall=this.geometry(p,n,tri);
  }
  gl.disable(gl.CULL_FACE);this.draw(scene.wall,7);gl.enable(gl.CULL_FACE);
 }
 drawContours(frame){
  const {scene,state,source}=frame,gl=this.gl;
  if(!scene.contours){
   const segments=this.shapeAPI.thicknessContours(this.shapeAPI.displayMesh(source)),p=[],n=[];
   for(const seg of segments)for(const q of seg.points){p.push([q[0],q[1],q[2]+.006]);n.push([0,0,1]);}
   const values=new Float32Array(p.length*6);p.forEach((q,i)=>{values.set(q,i*6);values.set(n[i],i*6+3);});scene.contours={buffer:this.buffer(values),positions:p,count:p.length,cut:null};
  }
  let lines=scene.contours;if(state.cut){if(!lines.cut){const p=[];for(let i=0;i<lines.positions.length;i+=2)if(lines.positions[i][0]<=1e-8&&lines.positions[i+1][0]<=1e-8)p.push(lines.positions[i],lines.positions[i+1]);const values=new Float32Array(p.length*6);p.forEach((q,i)=>{values.set(q,i*6);values.set([0,0,1],i*6+3);});lines.cut={buffer:this.buffer(values),count:p.length};}lines=lines.cut;}
  if(!lines.count)return;
  this.bind(lines);gl.uniform1i(this.uniforms.uMode,8);gl.uniform4f(this.uniforms.uColor,.955,.985,1.,1.);gl.uniform1f(this.uniforms.uDepthBias,-.00004);gl.lineWidth(1);gl.drawArrays(gl.LINES,0,lines.count);gl.uniform1f(this.uniforms.uDepthBias,0);
 }
 drawSelection(frame,index){
  const gl=this.gl,v=frame.source.vertices[index];if(frame.state.cut&&v.front[0]>1e-8)return;
  const p=this.projectPoint(v.front);if(!p||p[0]<0||p[1]<0||p[0]>frame.width||p[1]>frame.height)return;
  const hit=this.hitAt(p[0],p[1]);if(!hit||hit.sourceId===null||Math.abs(hit.depth-p[2])>.08)return;
  if(!this.selectionBuffer)this.selectionBuffer=this.buffer(new Float32Array(6));
  gl.bindBuffer(gl.ARRAY_BUFFER,this.selectionBuffer);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([...v.front,...v.frontNormal]),gl.DYNAMIC_DRAW);
  this.bind({buffer:this.selectionBuffer});gl.uniform1i(this.uniforms.uMode,10);gl.uniform1f(this.uniforms.uPointSize,Math.max(12,Math.min(18,frame.width*.017)));gl.uniform1f(this.uniforms.uDepthBias,-.00025);gl.drawArrays(gl.POINTS,0,1);gl.uniform1f(this.uniforms.uDepthBias,0);
 }
 projectPoint(p){
  const f=this.last;if(!f)return null;const q=this.shapeAPI.rotate([p[0],p[1],p[2]-f.centerZ],f.state.yaw,f.state.pitch,f.state.roll||0);
  const w=f.perspective?(f.perspective-q[2])/f.perspective:1;
  return [f.width*.5+q[0]*f.scale/w,f.height*.48-q[1]*f.scale/w,q[2],f.scale/w,w];
 }
 worldPoint(q){const f=this.last,r=f.rotation;return [dot(r[0],q),dot(r[1],q),dot(r[2],q)+f.centerZ];}
 opaqueDepth(x,y){
  const f=this.last,{scene}=f,qx=(x-f.width*.5)/f.scale,qy=(f.height*.48-y)/f.scale;
  const c=this.shapeAPI.rotate([0,0,scene.m.globeCenter-f.centerZ],f.state.yaw,f.state.pitch,f.state.roll||0);let depth=-Infinity;
  if(f.perspective){
   const origin=[0,0,f.perspective],direction=[qx,qy,-f.perspective],offset=sub(origin,c),aa=dot(direction,direction),bb=2*dot(offset,direction),cc=dot(offset,offset)-144,disc=bb*bb-4*aa*cc;
   if(disc>=0)for(const t of [(-bb-Math.sqrt(disc))/(2*aa),(-bb+Math.sqrt(disc))/(2*aa)]){const q=origin.map((v,i)=>v+t*direction[i]),p=this.worldPoint(q);if(t>0&&p[2]<=scene.m.limbusZ+.0001)depth=Math.max(depth,q[2]);}
   const ow=this.worldPoint(origin),dw=f.rotation.map(col=>dot(col,direction));
   if(Math.abs(dw[2])>1e-8){const t=(scene.irisZ-ow[2])/dw[2],p=ow.map((v,i)=>v+t*dw[i]);if(t>0&&Math.hypot(p[0],p[1])<=scene.irisRadius)depth=Math.max(depth,f.perspective*(1-t));}
  }else{
   const rr=144-(qx-c[0])**2-(qy-c[1])**2;
   if(rr>=0)for(const z of [c[2]+Math.sqrt(rr),c[2]-Math.sqrt(rr)]){const p=this.worldPoint([qx,qy,z]);if(p[2]<=scene.m.limbusZ+.0001)depth=Math.max(depth,z);}
   const zDir=f.rotation[2][2];if(Math.abs(zDir)>1e-7){const z=(scene.irisZ-f.centerZ-f.rotation[2][0]*qx-f.rotation[2][1]*qy)/zDir,p=this.worldPoint([qx,qy,z]);if(Math.hypot(p[0],p[1])<=scene.irisRadius)depth=Math.max(depth,z);}
  }
  return depth;
 }
 hitAt(x,y){
  const f=this.last;if(!f||!finite(x)||!finite(y)||x<0||y<0||x>=f.width||y>=f.height)return null;
  if(!f.projected)f.projected=f.scene.front.positions.map(p=>this.projectPoint(p));
  const points=f.projected,vertices=f.scene.m.vertices;let hit=null,best=this.opaqueDepth(x,y);
  for(const ids of f.scene.front.triangles){
   if(f.state.cut&&ids.some(i=>vertices[i].front[0]>1e-8))continue;
   const [a,b,c]=ids.map(i=>points[i]),den=(b[1]-c[1])*(a[0]-c[0])+(c[0]-b[0])*(a[1]-c[1]);
   if(den>=-.00000001||x<Math.min(a[0],b[0],c[0])-.01||x>Math.max(a[0],b[0],c[0])+.01||y<Math.min(a[1],b[1],c[1])-.01||y>Math.max(a[1],b[1],c[1])+.01)continue;
   let u=((b[1]-c[1])*(x-c[0])+(c[0]-b[0])*(y-c[1]))/den,v=((c[1]-a[1])*(x-c[0])+(a[0]-c[0])*(y-c[1]))/den,t=1-u-v;
   if(u<-.000001||v<-.000001||t<-.000001)continue;
   if(f.perspective){const sum=u/a[4]+v/b[4]+t/c[4];u=u/a[4]/sum;v=v/b[4]/sum;t=t/c[4]/sum;}
   const depth=u*a[2]+v*b[2]+t*c[2];if(depth<best-.000001)continue;
   const field=f.state.color==='combined'?'anterior':f.state.color,requiresMap=!['shape','form'].includes(f.state.color);
   const sourceId=ids.every(i=>vertices[i].sourceId>=0&&(!requiresMap||finite(vertices[i][field])))?vertices[ids[u>=v&&u>=t?0:v>=t?1:2]].sourceId:null;
   best=depth;hit={sourceId,depth,triangle:ids};
  }
  return hit;
 }
 pickAt(x,y){return this.hitAt(x,y)?.sourceId??null;}
 dispose(){
  if(this.disposed)return;this.disposed=true;this.available=false;if(this.onLost)this.canvas.removeEventListener?.('webglcontextlost',this.onLost,false);
  const gl=this.gl;if(gl){for(const b of this.buffers)gl.deleteBuffer(b);for(const p of this.programs)gl.deleteProgram(p);gl.getExtension?.('WEBGL_lose_context')?.loseContext?.();}this.buffers.clear();this.programs=[];this.meshCache=new WeakMap();this.last=null;
 }
}
AnatomicalEye.color=color;AnatomicalEye.paletteColor=color;AnatomicalEye.version='9.0.9';
if(typeof module!=='undefined'&&module.exports)module.exports=AnatomicalEye;else root.NKPIAnatomicalEye=AnatomicalEye;
})(typeof window!=='undefined'?window:globalThis);
